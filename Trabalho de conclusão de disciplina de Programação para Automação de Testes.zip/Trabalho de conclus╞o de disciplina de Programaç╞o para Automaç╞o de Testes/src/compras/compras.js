const calcularTotal = (ferramentas, comprar) => {
    const quantidadeDeFerramentas = ferramentas.length
    const quantidadeComprar = comprar.length

    if (quantidadeDeFerramentas === 0 || quantidadeComprar === 0) {
        throw new Error("Ambas as listas precisam ter ao menos um item.")
    }

    for (let indice = 0; indice < quantidadeDeFerramentas; indice++) {
        if (ferramentas[indice].nome == comprar[0]) {
            var ferramenta1 = ferramentas[indice].nome
            var valor1 = ferramentas[indice].preco
        } 

        if (ferramentas[indice].nome == comprar[1]) {
            var ferramenta2 = ferramentas[indice].nome
            var valor2 = ferramentas[indice].preco
        }
    }  

    if (!ferramenta1 || !ferramenta2) {
        throw new Error("Nenhuma ferramenta desejada encontrada.");
    }
    
    const total = valor1+valor2
    return `O valor a pagar pelas ferramentas (${ferramenta1}, ${ferramenta2}) é R$ ${total}.00`
}

module.exports = {
    calcularTotal
}

// const ferramentas = [
//     { nome: "UFT", preco: 100, fabricante: "OpenText" },
//     { nome: "TestComplete", preco: 200, fabricante: "Smartbear" },
//     { nome: "TOSCA", preco: 300, fabricante: "Tricents" }
// ];

// const comprar = [ "UFT", "TOSCA" ];

// // const resultado = calcularTotal(ferramentas, comprar);

// const quantidadeDeFerramentas = ferramentas.length

// for (let indice = 0; indice < quantidadeDeFerramentas; indice++) {
//     if (ferramentas[indice].nome == comprar[0]) {
//         var ferramenta1 = ferramentas[indice].nome
//         var valor1 = ferramentas[indice].preco
//     } 

//     if (ferramentas[indice].nome == comprar[1]) {
//         var ferramenta2 = ferramentas[indice].nome
//         var valor2 = ferramentas[indice].preco
//     }
// }

// const total = valor1+valor2

// console.log(ferramenta1)
// console.log(valor1)


// console.log(total)